import java.io.IOException;

public class Main {

    public Main() {
        
    }

    public static void main(String[] args) throws IOException {

        System.out.println("Start des Compilers...(Inicio do Compilador...)");
        Compiler comp = new Compiler();
        comp.Starten();
    }    
}